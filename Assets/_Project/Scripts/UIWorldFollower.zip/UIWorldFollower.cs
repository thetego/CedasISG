﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

namespace SafetyTraining
{






	// ═══════════════════════════════════════════════════════════════
	// 4) UIWorldFollower
	//    → Herhangi bir UI element'i 3D objeyi takip ettirir
	//    → UIClickButton veya UIDropZone'a ekle
	//    → LateUpdate'te WorldToScreenPoint ile pozisyon güncellenir
	// ═══════════════════════════════════════════════════════════════
	public class UIWorldFollower : MonoBehaviour
	{
		[Header("━━━ AYARLAR ━━━")]
		[Tooltip("Takip edilen 3D objenin Tag veya Name'i (runtime'da bulunur)")]
		public string targetObjectID;

		[Tooltip("World offset (obje üstüne ne kadar yukarı)")]
		public Vector3 worldOffset = Vector3.up * 1.5f;

		[Header("━━━ DEBUG ━━━")]
		public bool showDebug = false;

		// Runtime
		private Transform _target;
		private RectTransform _rt;
		private Camera _cam;
		private bool _isValid = false;

		private void Awake()
		{
			_rt = GetComponent<RectTransform>();
			_cam = Camera.main;
		}

		/// <summary>
		/// Target'ı bul ve takibi başlat
		/// Eğer target bulunamazsa objeyi deaktif eder ve uyarı verir
		/// </summary>
		public void Initialize(string targetID, Vector3 offset)
		{
			targetObjectID = targetID;
			worldOffset = offset;

			if (string.IsNullOrEmpty(targetID))
			{
				Debug.LogError("[UIWorldFollower] targetObjectID boş!");
				_isValid = false;
				gameObject.SetActive(false);
				return;
			}

			// SceneObjectRegistry üzerinden bul
			if (SceneObjectRegistry.Instance != null)
			{
				Transform targetTransform = SceneObjectRegistry.Instance.GetTransformByID(targetID);

				if (targetTransform != null)
				{
					_target = targetTransform;
					_isValid = true;

					if (showDebug)
						Debug.Log($"[UIWorldFollower] ✓ Target found via Registry: '{targetID}' at {targetTransform.position}");
					return;
				}
			}

			// Registry yoksa veya bulunamadıysa fallback: GameObject.Find
			GameObject obj = GameObject.Find(targetID);

			if (obj != null)
			{
				_target = obj.transform;
				_isValid = true;

				if (showDebug)
					Debug.Log($"[UIWorldFollower] ✓ Target found via Find: '{targetID}' (Fallback)");
			}
			else
			{
				Debug.LogError($"[UIWorldFollower] Target '{targetID}' not found! " +
							  $"Make sure a GameObject with SceneObject component has objectID='{targetID}'");
				_isValid = false;
				gameObject.SetActive(false);
			}
		}

		private void LateUpdate()
		{
			if (!_isValid || _target == null || _rt == null || _cam == null)
			{
				gameObject.SetActive(false);
				return;
			}

			Vector3 worldPos = _target.position + worldOffset;
			Vector3 screenPos = _cam.WorldToScreenPoint(worldPos);

			// Kameranın arkasında → gizle
			if (screenPos.z < 0)
			{
				gameObject.SetActive(false);
				return;
			}

			// Ekranın dışında → gizle (optional, isteğe göre)
			if (screenPos.x < -100 || screenPos.x > Screen.width + 100 ||
				screenPos.y < -100 || screenPos.y > Screen.height + 100)
			{
				gameObject.SetActive(false);
				return;
			}

			// Her şey yolunda → göster ve pozisyonu güncelle
			if (!gameObject.activeSelf)
				gameObject.SetActive(true);

			_rt.position = screenPos;
		}

		private void OnDrawGizmos()
		{
			if (!showDebug || _target == null) return;

			// World pozisyondan UI pozisyonuna çizgi çek (Scene view'de görünür)
			Gizmos.color = Color.cyan;
			Gizmos.DrawLine(_target.position, _target.position + worldOffset);
			Gizmos.DrawWireSphere(_target.position + worldOffset, 0.2f);
		}
	}
}