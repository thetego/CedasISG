﻿using UnityEngine;
using System.Collections.Generic;

namespace SafetyTraining
{
	/// <summary>
	/// UI elementlerini spawn eder ve yönetir
	/// Hem eski ActionManager hem yeni SequenceManager ile uyumlu
	/// </summary>
	public class UISpawnManager : MonoBehaviour
	{
		public static UISpawnManager Instance { get; private set; }

		[Header("━━━ PREFABS ━━━")]
		[Tooltip("Sekans butonu prefabı (UISequenceButton)")]
		public GameObject sequenceButtonPrefab;

		[Tooltip("Action butonu prefabı (UIActionButton)")]
		public GameObject actionButtonPrefab;

		[Tooltip("Click butonu prefabı (UIClickButton)")]
		public GameObject clickButtonPrefab;

		[Tooltip("Drop zone prefabı (UIDropZone)")]
		public GameObject dropZonePrefab;

		[Tooltip("Draggable item prefabı (UIDraggableItem)")]
		public GameObject draggableItemPrefab;

		[Header("━━━ CONTAINERS ━━━")]
		[Tooltip("World to screen butonlar için container (Canvas altında)")]
		public Transform worldButtonContainer;

		[Tooltip("Ekipman paneli container")]
		public RectTransform equipmentPanelContainer;

		[Tooltip("Inventory container (draggable itemlar)")]
		public Transform inventoryContainer;

		[Header("━━━ PANELS ━━━")]
		[Tooltip("Ekipman paneli (WearEquipment actionları için)")]
		public GameObject equipmentPanel;

		[Header("━━━ SETTINGS ━━━")]
		[Tooltip("World follower için default offset")]
		public Vector3 defaultWorldOffset = Vector3.up * 1.5f;

		[Header("━━━ DEBUG ━━━")]
		public bool debugMode = true;

		// ─── Runtime Storage ───
		private Dictionary<string, GameObject> _spawnedSequenceButtons = new Dictionary<string, GameObject>();
		private Dictionary<string, GameObject> _spawnedActionButtons = new Dictionary<string, GameObject>();
		private Dictionary<string, GameObject> _spawnedButtons = new Dictionary<string, GameObject>();
		private Dictionary<string, GameObject> _spawnedDropZones = new Dictionary<string, GameObject>();
		private Dictionary<string, GameObject> _spawnedItems = new Dictionary<string, GameObject>();
		private Dictionary<string, List<GameObject>> _actionUIElements = new Dictionary<string, List<GameObject>>();

		private void Awake()
		{
			if (Instance == null)
			{
				Instance = this;
			}
			else
			{
				Destroy(gameObject);
				return;
			}
		}

		// ═══════════════════════════════════════════════════════
		// YENİ SİSTEM: SEQUENCE BUTTON SPAWNING
		// ═══════════════════════════════════════════════════════

		/// <summary>
		/// Level başladığında tüm sekans butonlarını spawn eder (YENİ SİSTEM)
		/// </summary>
		public void SpawnSequenceButtons(LevelData level)
		{
			if (level == null || level.sequences == null)
			{
				Debug.LogError("[UISpawnManager] Level veya sequences null!");
				return;
			}

			CleanupSequenceButtons();

			foreach (var sequence in level.sequences)
			{
				if (sequence == null) continue;
				SpawnSequenceButton(sequence);
			}

			if (debugMode)
				Debug.Log($"<color=cyan>[UISpawnManager] Spawned {_spawnedSequenceButtons.Count} sequence buttons</color>");
		}

		private void SpawnSequenceButton(SequenceData sequence)
		{
			if (sequenceButtonPrefab == null || worldButtonContainer == null)
			{
				Debug.LogError("[UISpawnManager] sequenceButtonPrefab veya worldButtonContainer null!");
				return;
			}

			GameObject btnObj = Instantiate(sequenceButtonPrefab, worldButtonContainer);
			UISequenceButton btn = btnObj.GetComponent<UISequenceButton>();

			if (btn != null)
			{
				btn.Setup(
					sequence.sequenceID,
					sequence.sequenceName,
					sequence.sequenceIcon,
					sequence.buttonColor
				);

				// World follower ekle (eğer hedef obje varsa)
				if (!string.IsNullOrEmpty(sequence.targetObjectID))
				{
					UIWorldFollower follower = btnObj.GetComponent<UIWorldFollower>();
					if (follower == null)
						follower = btnObj.AddComponent<UIWorldFollower>();

					follower.Initialize(sequence.targetObjectID, sequence.buttonOffset);
				}

				// SequenceManager'a kaydet
				if (SequenceManager.Instance != null)
					SequenceManager.Instance.RegisterSequenceButton(sequence.sequenceID, btn);

				_spawnedSequenceButtons[sequence.sequenceID] = btnObj;
			}
		}

		private void CleanupSequenceButtons()
		{
			foreach (var kvp in _spawnedSequenceButtons)
			{
				if (kvp.Value != null)
					Destroy(kvp.Value);
			}
			_spawnedSequenceButtons.Clear();
		}

		// ═══════════════════════════════════════════════════════
		// ESKİ SİSTEM: ACTION BUTTON SPAWNING (BACKWARD COMPATIBILITY)
		// ═══════════════════════════════════════════════════════

		/// <summary>
		/// ActionManager için: Tüm action butonlarını spawn eder (ESKİ SİSTEM)
		/// </summary>
		public void SpawnAllActionButtons(LevelData level)
		{
			if (level == null || level.actionSequence == null)
			{
				Debug.LogError("[UISpawnManager] Level veya actionSequence null!");
				return;
			}

			CleanupActionButtons();

			foreach (var action in level.actionSequence)
			{
				if (action == null) continue;
				SpawnActionButton(action);
			}

			if (debugMode)
				Debug.Log($"<color=cyan>[UISpawnManager] Spawned {_spawnedActionButtons.Count} action buttons</color>");
		}

		private void SpawnActionButton(ActionData action)
		{
			if (actionButtonPrefab == null || worldButtonContainer == null)
			{
				Debug.LogError("[UISpawnManager] actionButtonPrefab veya worldButtonContainer null!");
				return;
			}

			GameObject btnObj = Instantiate(actionButtonPrefab, worldButtonContainer);
			UIActionButton btn = btnObj.GetComponent<UIActionButton>();

			if (btn != null)
			{
				btn.Setup(action.actionID, action.actionName);

				// World follower ekle (eğer hedef obje varsa)
				if (!string.IsNullOrEmpty(action.targetObjectID))
				{
					UIWorldFollower follower = btnObj.GetComponent<UIWorldFollower>();
					if (follower == null)
						follower = btnObj.AddComponent<UIWorldFollower>();

					follower.Initialize(action.targetObjectID, defaultWorldOffset);
				}

				// ActionManager'a kaydet
				if (ActionManager.Instance != null)
					ActionManager.Instance.RegisterActionButton(action.actionID, btn);

				_spawnedActionButtons[action.actionID] = btnObj;
			}
		}

		private void CleanupActionButtons()
		{
			foreach (var kvp in _spawnedActionButtons)
			{
				if (kvp.Value != null)
					Destroy(kvp.Value);
			}
			_spawnedActionButtons.Clear();
		}

		/// <summary>
		/// LevelManager için: Tüm UI'ları spawn eder ama deaktif tutar (ESKİ SİSTEM)
		/// </summary>
		public void SpawnAllUI(LevelData level)
		{
			if (level == null || level.actionSequence == null)
			{
				Debug.LogError("[UISpawnManager] Level veya actionSequence null!");
				return;
			}

			CleanupAllUI();

			foreach (var action in level.actionSequence)
			{
				if (action == null) continue;
				SpawnUIForAction(action);
			}

			// Ekipman panelini kapat
			if (equipmentPanel)
				equipmentPanel.SetActive(false);

			if (debugMode)
				Debug.Log($"<color=cyan>[UISpawnManager] Spawned UI for {level.actionSequence.Length} actions</color>");
		}

		// ═══════════════════════════════════════════════════════
		// ORTAK: ACTION UI SPAWNING (HER İKİ SİSTEM İÇİN)
		// ═══════════════════════════════════════════════════════

		/// <summary>
		/// Action aktif olduğunda ilgili UI'ları gösterir
		/// </summary>
		public void ActivateAction(ActionData action)
		{
			if (action == null) return;

			// Eğer UI daha önce spawn edilmemişse, şimdi spawn et
			if (!_actionUIElements.ContainsKey(action.actionID))
			{
				SpawnUIForAction(action);
			}

			// Action'a ait UI'ları aktif et
			if (_actionUIElements.TryGetValue(action.actionID, out List<GameObject> elements))
			{
				foreach (var element in elements)
				{
					if (element != null)
						element.SetActive(true);
				}
			}

			// Ekipman panelini aç (WearEquipment için)
			if (action.actionType == ActionType.WearEquipment && equipmentPanel != null)
			{
				equipmentPanel.SetActive(true);
			}

			if (debugMode)
				Debug.Log($"<color=green>[UISpawnManager] Activated UI for action: {action.actionName}</color>");
		}

		/// <summary>
		/// Action tamamlandığında UI'ları deaktif eder
		/// </summary>
		public void DeactivateAction(ActionData action)
		{
			if (action == null) return;

			// Action'a ait UI'ları deaktif et
			if (_actionUIElements.TryGetValue(action.actionID, out List<GameObject> elements))
			{
				foreach (var element in elements)
				{
					if (element != null)
						element.SetActive(false);
				}
			}

			// Ekipman panelini kapat (WearEquipment için)
			if (action.actionType == ActionType.WearEquipment && equipmentPanel != null)
			{
				equipmentPanel.SetActive(false);
			}

			if (debugMode)
				Debug.Log($"<color=yellow>[UISpawnManager] Deactivated UI for action: {action.actionName}</color>");
		}

		private void SpawnUIForAction(ActionData action)
		{
			List<GameObject> uiElements = new List<GameObject>();

			switch (action.actionType)
			{
				case ActionType.Click:
				case ActionType.OpenClose:
					GameObject clickBtn = SpawnClickButton(action);
					if (clickBtn != null) uiElements.Add(clickBtn);
					break;

				case ActionType.WearEquipment:
					uiElements.AddRange(SpawnEquipmentUI(action));
					break;

				case ActionType.DragToWorld:
					GameObject dragUI = SpawnDragToWorldUI(action);
					if (dragUI != null) uiElements.Add(dragUI);
					break;

				case ActionType.CameraMove:
					// Kamera hareketi için UI gerekmez
					break;
			}

			if (uiElements.Count > 0)
			{
				_actionUIElements[action.actionID] = uiElements;

				// Başlangıçta deaktif
				foreach (var ui in uiElements)
				{
					if (ui != null)
						ui.SetActive(false);
				}
			}
		}

		private GameObject SpawnClickButton(ActionData action)
		{
			if (clickButtonPrefab == null || worldButtonContainer == null)
			{
				Debug.LogError("[UISpawnManager] clickButtonPrefab veya worldButtonContainer null!");
				return null;
			}

			GameObject btnObj = Instantiate(clickButtonPrefab, worldButtonContainer);
			UIClickButton btn = btnObj.GetComponent<UIClickButton>();

			if (btn != null)
			{
				btn.Setup(action.actionID, action.actionName);
			}

			// World follower ekle
			if (!string.IsNullOrEmpty(action.targetObjectID))
			{
				UIWorldFollower follower = btnObj.GetComponent<UIWorldFollower>();
				if (follower == null)
					follower = btnObj.AddComponent<UIWorldFollower>();

				follower.Initialize(action.targetObjectID, defaultWorldOffset);
			}

			_spawnedButtons[action.actionID] = btnObj;
			return btnObj;
		}

		private List<GameObject> SpawnEquipmentUI(ActionData action)
		{
			List<GameObject> elements = new List<GameObject>();

			if (action.requiredEquipments == null || action.requiredEquipments.Length == 0)
			{
				Debug.LogWarning($"[UISpawnManager] Action '{action.actionID}' has no required equipments!");
				return elements;
			}

			// Drop zone'lar spawn et (equipment panel içinde)
			if (dropZonePrefab != null && equipmentPanelContainer != null)
			{
				foreach (var eq in action.requiredEquipments)
				{
					if (eq == null) continue;

					GameObject zoneObj = Instantiate(dropZonePrefab, equipmentPanelContainer);
					UIDropZone zone = zoneObj.GetComponent<UIDropZone>();

					if (zone != null)
					{
						zone.SetupAsEquipmentSlot(action.actionID, eq.slotType, eq.equipmentName);
					}

					elements.Add(zoneObj);
					_spawnedDropZones[$"{action.actionID}_{eq.equipmentID}"] = zoneObj;
				}
			}

			// Draggable itemlar spawn et (inventory içinde)
			if (draggableItemPrefab != null && inventoryContainer != null)
			{
				foreach (var eq in action.requiredEquipments)
				{
					if (eq == null) continue;

					GameObject itemObj = Instantiate(draggableItemPrefab, inventoryContainer);
					UIDraggableItem item = itemObj.GetComponent<UIDraggableItem>();

					if (item != null)
					{
						item.Setup(eq.equipmentID, eq.equipmentName, eq.equipmentIcon, eq);
					}

					elements.Add(itemObj);
					_spawnedItems[$"{action.actionID}_{eq.equipmentID}"] = itemObj;
				}
			}

			return elements;
		}

		private GameObject SpawnDragToWorldUI(ActionData action)
		{
			if (dropZonePrefab == null || worldButtonContainer == null)
			{
				Debug.LogError("[UISpawnManager] dropZonePrefab veya worldButtonContainer null!");
				return null;
			}

			// Drop zone spawn et
			GameObject zoneObj = Instantiate(dropZonePrefab, worldButtonContainer);
			UIDropZone zone = zoneObj.GetComponent<UIDropZone>();

			if (zone != null)
			{
				zone.SetupAsToolDrop(action.actionID, action.toolItemID, "Drop Here", action.dropZoneSize);
			}

			// World follower ekle
			if (!string.IsNullOrEmpty(action.dropTargetObjectID))
			{
				UIWorldFollower follower = zoneObj.GetComponent<UIWorldFollower>();
				if (follower == null)
					follower = zoneObj.AddComponent<UIWorldFollower>();

				follower.Initialize(action.dropTargetObjectID, defaultWorldOffset);
			}

			_spawnedDropZones[action.actionID] = zoneObj;

			return zoneObj;
		}

		// ═══════════════════════════════════════════════════════
		// CLEANUP
		// ═══════════════════════════════════════════════════════

		/// <summary>
		/// Tüm spawn edilmiş UI'ları temizler
		/// </summary>
		public void CleanupAllUI()
		{
			// Sekans butonlarını temizle
			CleanupSequenceButtons();

			// Action butonlarını temizle
			CleanupActionButtons();

			// Click butonlarını temizle
			foreach (var kvp in _spawnedButtons)
			{
				if (kvp.Value != null)
					Destroy(kvp.Value);
			}
			_spawnedButtons.Clear();

			// Drop zone'ları temizle
			foreach (var kvp in _spawnedDropZones)
			{
				if (kvp.Value != null)
					Destroy(kvp.Value);
			}
			_spawnedDropZones.Clear();

			// Item'ları temizle
			foreach (var kvp in _spawnedItems)
			{
				if (kvp.Value != null)
					Destroy(kvp.Value);
			}
			_spawnedItems.Clear();

			// UI element listelerini temizle
			_actionUIElements.Clear();

			if (debugMode)
				Debug.Log("[UISpawnManager] All UI cleaned up");
		}
	}
}