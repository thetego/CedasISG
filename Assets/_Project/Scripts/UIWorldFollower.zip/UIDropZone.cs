﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

namespace SafetyTraining
{
	/// <summary>
	/// Drop zone - ekipman slotu veya tool drop alanı
	/// SequenceManager ile çalışır
	/// </summary>
	public class UIDropZone : MonoBehaviour,
			IPointerEnterHandler, IPointerExitHandler
	{
		[Header("━━━ REFERANSLAR ━━━")]
		public Image background;
		public Image icon;
		public TextMeshProUGUI label;

		[Header("━━━ BOYUT ━━━")]
		public Vector2 zoneSize = new Vector2(100, 100);
		public bool autoResizeOnSetup = true;

		[Header("━━━ RENKLER ━━━")]
		public Color normalColor = new Color(1f, 1f, 1f, 0.3f);
		public Color hoverValid = new Color(0.2f, 1f, 0.2f, 0.55f);
		public Color hoverInvalid = new Color(1f, 0.2f, 0.2f, 0.55f);
		public Color filledColor = new Color(0.2f, 0.85f, 1f, 0.8f);

		[Header("━━━ DEBUG ━━━")]
		public bool debugMode = false;

		// Runtime
		private string _actionID;
		private string _acceptedItemID;
		private EquipmentSlotType _slotType;
		private bool _isEquipmentSlot;
		private bool _filled;
		private RectTransform _rectTransform;

		private void Awake()
		{
			_rectTransform = GetComponent<RectTransform>();
		}

		public void SetupAsToolDrop(string actionID, string acceptedItemID, string labelText, Vector2? customSize = null)
		{
			if (string.IsNullOrEmpty(actionID))
			{
				Debug.LogError("[UIDropZone] SetupAsToolDrop called with empty actionID!");
				return;
			}

			_actionID = actionID;
			_acceptedItemID = acceptedItemID;
			_isEquipmentSlot = false;
			_filled = false;

			if (label != null) label.text = labelText;
			if (background != null) background.color = normalColor;

			if (customSize.HasValue)
				zoneSize = customSize.Value;

			if (autoResizeOnSetup)
				ApplySize();

			gameObject.SetActive(false);

			if (debugMode)
				Debug.Log($"[UIDropZone] Setup as tool drop: {actionID} (accepts: {acceptedItemID})");
		}

		public void SetupAsEquipmentSlot(string actionID, EquipmentSlotType slotType, string labelText, Vector2? customSize = null)
		{
			if (string.IsNullOrEmpty(actionID))
			{
				Debug.LogError("[UIDropZone] SetupAsEquipmentSlot called with empty actionID!");
				return;
			}

			_actionID = actionID;
			_slotType = slotType;
			_isEquipmentSlot = true;
			_filled = false;

			if (label != null) label.text = labelText;
			if (background != null) background.color = normalColor;

			if (customSize.HasValue)
				zoneSize = customSize.Value;

			if (autoResizeOnSetup)
				ApplySize();

			gameObject.SetActive(false);

			if (debugMode)
				Debug.Log($"[UIDropZone] Setup as equipment slot: {actionID} (slot: {slotType})");
		}

		public void ApplySize()
		{
			if (_rectTransform != null)
			{
				_rectTransform.sizeDelta = zoneSize;
			}
		}

		public void SetSize(Vector2 newSize)
		{
			zoneSize = newSize;
			ApplySize();
		}

		public void SetActive(bool state) => gameObject.SetActive(state);

		public bool TryAcceptItem(UIDraggableItem item)
		{
			if (item == null || _filled) return false;

			bool accepted = false;

			if (_isEquipmentSlot)
			{
				accepted = item.EquipmentData != null && item.EquipmentData.slotType == _slotType;
			}
			else
			{
				accepted = item.ItemID == _acceptedItemID;
			}

			if (!accepted) return false;

			AcceptItem(item);
			return true;
		}

		private void AcceptItem(UIDraggableItem item)
		{
			_filled = true;

			item.transform.SetParent(transform);

			RectTransform itemRT = item.GetComponent<RectTransform>();
			if (itemRT != null)
				itemRT.anchoredPosition = Vector2.zero;

			CanvasGroup itemCG = item.GetComponent<CanvasGroup>();
			if (itemCG != null)
				itemCG.blocksRaycasts = false;

			if (background != null)
				background.color = filledColor;

			if (icon != null && item.ItemIconSprite != null)
			{
				icon.sprite = item.ItemIconSprite;
				icon.enabled = true;
			}

			// SequenceManager'a bildir
			if (SequenceManager.Instance != null)
			{
				if (item.EquipmentData != null)
					SequenceManager.Instance.OnEquipmentWorn(item.EquipmentData);
				else
					SequenceManager.Instance.OnToolDropped(_actionID);
			}
			else
			{
				Debug.LogWarning("[UIDropZone] SequenceManager.Instance is null!");
			}

			if (debugMode)
				Debug.Log($"<color=green>[UIDropZone] Item accepted: {item.ItemID}</color>");
		}

		public void OnPointerEnter(PointerEventData e)
		{
			if (_filled || background == null) return;

			UIDraggableItem dragged = e.pointerDrag?.GetComponent<UIDraggableItem>();
			if (dragged == null) return;

			bool canAccept = CanAcceptItem(dragged);
			background.color = canAccept ? hoverValid : hoverInvalid;
		}

		public void OnPointerExit(PointerEventData e)
		{
			if (background == null) return;
			background.color = _filled ? filledColor : normalColor;
		}

		private bool CanAcceptItem(UIDraggableItem item)
		{
			if (item == null) return false;

			if (_isEquipmentSlot)
				return item.EquipmentData != null && item.EquipmentData.slotType == _slotType;
			else
				return item.ItemID == _acceptedItemID;
		}

		public void Reset()
		{
			_filled = false;
			if (background != null) background.color = normalColor;
			if (icon != null) icon.enabled = false;
		}
	}
}