﻿using SafetyTraining;
using UnityEngine.Events;
using UnityEngine;

namespace SafetyTraining
{
	public enum ActionType
	{
		WearEquipment,   // Ekipman giyme → Drag item → Drop zone (sabit panel)
		OpenClose,       // Kapı/kapak → UI buton (world to screen)
		DragToWorld,     // Tool sürükle → Drop zone (world to screen)
		Click,           // Basit tıklama → UI buton (world to screen)
		CameraMove       // Otomatik kamera geçiş
	}

	public enum PrerequisiteFailAction
	{
		Block,      // Butonu disabled yap, tıklanmaz
		Warning,    // Uyarı göster ama devam edilebilir
		GameOver    // Kritik hata, oyun biter
	}

	public enum CameraMode
	{
		Keep,           // Mevcut kamerayı koru
		General,        // Genel sahne kamerası
		Character,      // Karakter kamerası
		ObjectClose,    // Obje yakın plan
		Custom          // Özel virtual camera (virtualCameraID ile)
	}

	public enum AnimatorParameterType { Trigger, Bool, Float, Int }
	public enum AnimationTiming { OnStart, OnComplete, OnFail }

	[System.Serializable]
	public class AnimationTriggerData
	{
		public string animatorObjectID;
		public string triggerName;
		public AnimatorParameterType parameterType = AnimatorParameterType.Trigger;
		public float parameterValue = 1f;
		public AnimationTiming timing = AnimationTiming.OnComplete;
	}

	[CreateAssetMenu(fileName = "New Action", menuName = "Safety Training/Action Data")]
	public class ActionData : ScriptableObject
	{
		[Header("━━━ GENEL ━━━")]
		public string actionID;
		public string actionName;
		[TextArea(2, 5)]
		public string instructionText;
		public ActionType actionType;

		[Header("━━━ PREREQUISITE SYSTEM ━━━")]
		[Tooltip("Bu actiondan önce tamamlanması gereken action ID'leri")]
		public string[] prerequisiteActionIDs;

		[Tooltip("Prerequisite sağlanmadığında ne olacak?")]
		public PrerequisiteFailAction onPrerequisiteFail = PrerequisiteFailAction.Block;

		[Tooltip("Prerequisite hatası mesajı")]
		[TextArea(2, 4)]
		public string prerequisiteFailMessage = "Bu aksiyonu yapmak için önce gerekli adımları tamamlamalısınız.";

		[Header("━━━ TAMAMLANMA AYARLARI ━━━")]
		[Tooltip("Action tamamlandıktan sonra bekleme süresi")]
		[Range(0f, 10f)]
		public float completionDelay = 0f;

		[Tooltip("Delay sonunda otomatik devam et")]
		public bool autoCompleteAfterDelay = false;

		[Header("━━━ CAMERA SETTINGS ━━━")]
		[Tooltip("Action için kamera modu")]
		public CameraMode cameraMode = CameraMode.Keep;

		[Tooltip("Özel kamera ID'si (Custom veya ObjectClose modunda)")]
		public string virtualCameraID;

		[Tooltip("Action tamamlandığında otomatik kamera geri dönsün mü?")]
		public bool autoReturnCameraOnComplete = false;

		[Header("━━━ KAMERA HAREKETİ (CameraMove için - DEPRECATED) ━━━")]
		[Tooltip("Kameranın gideceği hedef objenin Tag/Name'i")]
		public string cameraTargetID;

		[Tooltip("Kamera hareket hızı")]
		[Range(0.5f, 5f)]
		public float cameraMoveSpeed = 2f;

		[Tooltip("Kamera hareketinden sonra otomatik tamamlansın mı?")]
		public bool autoCompleteAfterCamera = true;

		[Header("━━━ KOŞULLAR (DEPRECATED) ━━━")]
		[Tooltip("Önceki action tamamlanmadan bu başlamasın mı? (deprecated - prerequisiteActionIDs kullanın)")]
		public bool requiresPreviousAction = true;

		[Tooltip("Bu actiondan önce tamamlanması gereken actionlar (deprecated - prerequisiteActionIDs kullanın)")]
		public ActionData[] prerequisiteActions;

		// ───────────────────────────────────────
		// HEDEF OBJE (World to Screen için)
		// Sahnedeki objenin Tag'i veya Name'i
		// ───────────────────────────────────────
		[Header("━━━ HEDEF OBJE (Sahne) ━━━")]
		[Tooltip("Sahnedeki 3D objenin Tag veya Name'i. UI otomatik burada belir.")]
		public string targetObjectID;

		// ───────────────────────────────────────
		// WearEquipment
		// ───────────────────────────────────────
		[Header("━━━ EKIPMAN (WearEquipment) ━━━")]
		[Tooltip("Giyilmesi gereken ekipmanlar listesi (sıra önemsiz, hepsi giyilmeli)")]
		public EquipmentData[] requiredEquipments;

		// ───────────────────────────────────────
		// DragToWorld
		// ───────────────────────────────────────
		[Header("━━━ DRAG TO WORLD ━━━")]
		[Tooltip("Sürüklenecek tool'un ID'si (ToolData veya item ID)")]
		public string toolItemID;
		[Tooltip("Drop zone'un hedef obje ID'si (sahne objesinin ID'si)")]
		public string dropTargetObjectID;
		[Tooltip("Drop zone boyutu (piksel) - 0 ise default")]
		public Vector2 dropZoneSize = new Vector2(120, 120);

		// ───────────────────────────────────────
		// UI BEHAVIOR
		// ───────────────────────────────────────
		[Header("━━━ UI BEHAVIOR ━━━")]
		[Tooltip("Tamamlandıktan sonra butonu gizle")]
		public bool hideButtonAfterComplete = false;

		// ───────────────────────────────────────
		// ANİMASYONLAR & EFEKTLER
		// ───────────────────────────────────────
		[Header("━━━ ANİMASYONLAR ━━━")]
		public AnimationTriggerData[] animationTriggers;

		[Header("━━━ EFEKTLER ━━━")]
		public AudioClip soundClip;
		public string particleEffectID;
		public Vector3 particleSpawnOffset;

		// ───────────────────────────────────────
		// EVENTS
		// ───────────────────────────────────────
		[Header("━━━ EVENTS ━━━")]
		public UnityEvent onActionStart;
		public UnityEvent onActionComplete;
		public UnityEvent onActionFail;

		public AnimationTriggerData[] GetAnimationsForTiming(AnimationTiming timing)
		{
			if (animationTriggers == null) return new AnimationTriggerData[0];
			return System.Array.FindAll(animationTriggers, a => a.timing == timing);
		}
	}
}